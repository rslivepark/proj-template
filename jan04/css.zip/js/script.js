import './login-join';
import './newsfeed';

console.log('script.js');
